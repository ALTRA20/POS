<?php $_SESSION['last_url'] = $_SERVER[REQUEST_URI]; ?>
<?php
include $_SERVER['DOCUMENT_ROOT'].'/components/header/index.php'; ?>

<?php include $_SERVER['DOCUMENT_ROOT'].'/components/header/index.php'; ?>