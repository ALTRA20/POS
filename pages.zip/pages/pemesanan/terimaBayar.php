<?php include $_SERVER['DOCUMENT_ROOT'].'/components/header/index.php'; ?>
<?php include $_SERVER['DOCUMENT_ROOT'].'/components/pemesanan/terimaBayarIndex.php'; ?>
<?php include $_SERVER['DOCUMENT_ROOT'].'/components/footer/index.php'; ?>