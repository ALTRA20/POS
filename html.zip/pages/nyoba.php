<?php 
var_dump(session_start());