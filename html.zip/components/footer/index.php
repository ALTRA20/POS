
<script src="/lib/jquery.min.js"></script>
<script src="/lib/popper.min.js"></script>
<script src="/lib/bootstrap.min.js"></script>
<script src="/function/select.js"></script>
</body>
</html>