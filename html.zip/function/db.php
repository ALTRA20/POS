<?php
$db = new mysqli("localhost","root", "root","sembako");